const { ethers } = require("hardhat");

async function main() {
  const [deployer] = await ethers.getSigners();
  const enjeu = ethers.parseEther("0.01");

  console.log("Déploiement par :", deployer.address);
  console.log("Enjeu :", ethers.formatEther(enjeu), "ETH");

  const BattleshipGame = await ethers.getContractFactory("BattleshipGame");
  const game = await BattleshipGame.deploy({ value: enjeu });
  await game.waitForDeployment();

  console.log("BattleshipGame déployé à :", await game.getAddress());
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
