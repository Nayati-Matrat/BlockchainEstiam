// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title BattleshipGame
 * @notice Jeu de bataille navale simplifié (grille 3x3, 1 bateau de 2 cases) entre deux joueurs.
 * @dev Le hash du placement est soumis avant le début. La vérification on-chain se fait à la fin.
 */
contract BattleshipGame {

    // ─────────────────────────────────────────────
    //  Enums & Structs
    // ─────────────────────────────────────────────

    /// @notice États possibles de la partie
    enum GameState {
        WaitingPlayer,  // En attente du joueur 2
        WaitingHashes,  // Les deux joueurs sont là, en attente des hashs
        InProgress,     // Partie en cours
        Finished        // Partie terminée
    }

    /// @notice Statut d'une case après une attaque
    enum AttackStatus {
        Manque,  // 0 - Raté
        Touche,  // 1 - Touché
        Coule    // 2 - Coulé (fin de partie)
    }

    /// @notice Enregistrement d'une attaque sur une grille
    struct AttackRecord {
        uint8 caseVisee;
        AttackStatus statut;
    }

    // ─────────────────────────────────────────────
    //  Variables d'état
    // ─────────────────────────────────────────────

    address public joueur1;
    address public joueur2;
    uint256 public enjeu;

    bytes32 public hashJoueur1;
    bytes32 public hashJoueur2;
    bool public hashSoumisJ1;
    bool public hashSoumisJ2;

    /// @notice Joueur dont c'est le tour d'agir (attaque ou réponse)
    address public joueurCourant;

    /// @notice Indique si on attend une réponse à une attaque (true) ou une attaque (false)
    bool public enAttenteReponse;

    /// @notice Dernière case attaquée, en attente de réponse
    uint8 public derniereCase;

    /// @notice Historique des attaques sur la grille du joueur 1 (attaques du joueur 2)
    AttackRecord[] public attaquesGrilleJ1;
    /// @notice Historique des attaques sur la grille du joueur 2 (attaques du joueur 1)
    AttackRecord[] public attaquesGrilleJ2;

    GameState public etat;

    /// @notice Numéro de bloc de la dernière action (pour détecter l'inactivité)
    uint256 public blocDerniereAction;

    /// @notice Nombre de blocs d'inactivité avant de pouvoir réclamer la victoire
    uint256 public constant BLOCS_INACTIVITE = 50;

    // ─────────────────────────────────────────────
    //  Events
    // ─────────────────────────────────────────────

    event JoueurRejoint(address indexed joueur2, uint256 enjeu);
    event HashSoumis(address indexed joueur);
    event PartieCommencee(address indexed premierAttaquant);
    event Attaque(address indexed attaquant, uint8 caseVisee);
    event Reponse(address indexed repondant, uint8 caseVisee, AttackStatus statut);
    event VictoireReclamee(address indexed vainqueur, uint256 montant);
    event VictoireInactivite(address indexed vainqueur, uint256 montant);

    // ─────────────────────────────────────────────
    //  Custom Errors
    // ─────────────────────────────────────────────

    error PartieDejaPleine();
    error EnjeuIncorrect(uint256 attendu, uint256 recu);
    error EtatIncorrect(GameState attendu, GameState actuel);
    error PasTonTour(address joueurCourant, address appelant);
    error CaseHorsLimites(uint8 caseVisee);
    error CaseDejaAttaquee(uint8 caseVisee);
    error AucuneAttaqueEnAttente();
    error HashDejasoumis();
    error HashInvalide();
    error PlacementInvalide();
    error InactiviteInsuffisante(uint256 blocsEcoules, uint256 blocsRequis);
    error TropTot();

    // ─────────────────────────────────────────────
    //  Modifiers
    // ─────────────────────────────────────────────

    modifier seulementEtat(GameState _etat) {
        if (etat != _etat) revert EtatIncorrect(_etat, etat);
        _;
    }

    modifier seulementJoueurCourant() {
        if (msg.sender != joueurCourant) revert PasTonTour(joueurCourant, msg.sender);
        _;
    }

    modifier seulementJoueurs() {
        if (msg.sender != joueur1 && msg.sender != joueur2) revert PasTonTour(joueurCourant, msg.sender);
        _;
    }

    // ─────────────────────────────────────────────
    //  Constructeur
    // ─────────────────────────────────────────────

    /**
     * @notice Déploie le contrat et enregistre le joueur 1.
     * @dev L'enjeu correspond à msg.value envoyé lors du déploiement.
     */
    constructor() payable {
        require(msg.value > 0, "Enjeu nul interdit");
        joueur1 = msg.sender;
        enjeu = msg.value;
        etat = GameState.WaitingPlayer;
        blocDerniereAction = block.number;
    }

    // ─────────────────────────────────────────────
    //  Fonctions publiques
    // ─────────────────────────────────────────────

    /**
     * @notice Permet au joueur 2 de rejoindre la partie en envoyant le même enjeu.
     */
    function joinGame() external payable seulementEtat(GameState.WaitingPlayer) {
        if (msg.sender == joueur1) revert PartieDejaPleine();
        if (msg.value != enjeu) revert EnjeuIncorrect(enjeu, msg.value);

        joueur2 = msg.sender;
        etat = GameState.WaitingHashes;
        blocDerniereAction = block.number;

        emit JoueurRejoint(msg.sender, msg.value);
    }

    /**
     * @notice Soumet le hash du placement du bateau.
     * @dev hash = keccak256(abi.encodePacked(case1, case2, sel))
     * @param _hash Hash salé du placement (case1, case2, sel)
     */
    function submitHash(bytes32 _hash) external seulementEtat(GameState.WaitingHashes) {
        if (msg.sender == joueur1) {
            if (hashSoumisJ1) revert HashDejasoumis();
            hashJoueur1 = _hash;
            hashSoumisJ1 = true;
        } else if (msg.sender == joueur2) {
            if (hashSoumisJ2) revert HashDejasoumis();
            hashJoueur2 = _hash;
            hashSoumisJ2 = true;
        } else {
            revert PasTonTour(joueurCourant, msg.sender);
        }

        emit HashSoumis(msg.sender);

        // Si les deux hashs sont soumis, la partie commence — c'est J2 qui attaque en premier
        if (hashSoumisJ1 && hashSoumisJ2) {
            etat = GameState.InProgress;
            joueurCourant = joueur2;
            enAttenteReponse = false;
            blocDerniereAction = block.number;
            emit PartieCommencee(joueur2);
        }
    }

    /**
     * @notice Le joueur courant attaque une case de la grille adverse.
     * @param _case Index de la case visée (0 à 8)
     */
    function attack(uint8 _case)
        external
        seulementEtat(GameState.InProgress)
        seulementJoueurCourant
    {
        if (enAttenteReponse) revert AucuneAttaqueEnAttente();
        if (_case > 8) revert CaseHorsLimites(_case);

        // Vérifier que la case n'a pas déjà été attaquée sur la grille adverse
        if (joueurCourant == joueur1) {
            _verifierCasePasDejaAttaquee(_case, attaquesGrilleJ2);
        } else {
            _verifierCasePasDejaAttaquee(_case, attaquesGrilleJ1);
        }

        derniereCase = _case;
        enAttenteReponse = true;
        blocDerniereAction = block.number;

        emit Attaque(msg.sender, _case);
    }

    /**
     * @notice L'adversaire répond à l'attaque en cours.
     * @param _statut 0 = Manqué, 1 = Touché, 2 = Coulé
     */
    function respondToAttack(AttackStatus _statut)
        external
        seulementEtat(GameState.InProgress)
    {
        if (!enAttenteReponse) revert AucuneAttaqueEnAttente();

        // C'est l'adversaire du joueur courant qui doit répondre
        address adversaire = (joueurCourant == joueur1) ? joueur2 : joueur1;
        if (msg.sender != adversaire) revert PasTonTour(adversaire, msg.sender);

        // Enregistrement de l'attaque dans l'historique de la grille de l'adversaire
        if (joueurCourant == joueur1) {
            attaquesGrilleJ2.push(AttackRecord({ caseVisee: derniereCase, statut: _statut }));
        } else {
            attaquesGrilleJ1.push(AttackRecord({ caseVisee: derniereCase, statut: _statut }));
        }

        enAttenteReponse = false;
        blocDerniereAction = block.number;

        emit Reponse(msg.sender, derniereCase, _statut);

        if (_statut == AttackStatus.Coule) {
            // Fin de partie : le joueur courant (attaquant) gagne
            etat = GameState.Finished;
            // Ne pas transférer ici — attendre claimWin avec vérification du hash
        } else if (_statut == AttackStatus.Manque) {
            // Changement de joueur
            joueurCourant = adversaire;
        }
        // Si Touché : le même joueur rejoue (joueurCourant inchangé)
    }

    /**
     * @notice Le vainqueur réclame sa victoire en révélant ses positions et son sel.
     * @dev Vérifie le hash on-chain, puis transfère les fonds.
     * @param _case1 Première case du bateau
     * @param _case2 Deuxième case du bateau
     * @param _sel Sel secret utilisé lors du hash
     */
    function claimWin(uint8 _case1, uint8 _case2, bytes32 _sel) external {
        if (etat != GameState.Finished) revert EtatIncorrect(GameState.Finished, etat);
        if (msg.sender != joueurCourant) revert PasTonTour(joueurCourant, msg.sender);

        // Validation du placement
        if (_case1 > 8 || _case2 > 8) revert PlacementInvalide();
        if (!_placementConsecutif(_case1, _case2)) revert PlacementInvalide();

        // Vérification du hash
        bytes32 hashCalcule = keccak256(abi.encodePacked(_case1, _case2, _sel));
        bytes32 hashAttendu = (msg.sender == joueur1) ? hashJoueur1 : hashJoueur2;
        if (hashCalcule != hashAttendu) revert HashInvalide();

        uint256 gain = address(this).balance;

        // Checks-Effects-Interactions : mettre à jour l'état avant le transfert
        etat = GameState.Finished; // déjà Finished, mais on s'assure de l'état
        joueurCourant = address(0); // empêche un double appel

        emit VictoireReclamee(msg.sender, gain);

        (bool succes, ) = msg.sender.call{ value: gain }("");
        require(succes, "Transfert echoue");
    }

    /**
     * @notice Permet à un joueur de réclamer la victoire si l'adversaire est inactif.
     * @dev Utilisable uniquement si BLOCS_INACTIVITE blocs se sont écoulés sans action.
     */
    function claimInactivity() external seulementJoueurs {
        if (etat != GameState.InProgress && etat != GameState.WaitingHashes) {
            revert TropTot();
        }

        uint256 blocsEcoules = block.number - blocDerniereAction;
        if (blocsEcoules < BLOCS_INACTIVITE) {
            revert InactiviteInsuffisante(blocsEcoules, BLOCS_INACTIVITE);
        }

        // L'appelant doit être celui qui attend (pas le joueur courant en retard)
        // En WaitingHashes : le joueur qui a soumis son hash peut sanctionner l'autre
        // En InProgress : l'adversaire du joueur courant peut le sanctionner
        address vainqueur;
        if (etat == GameState.WaitingHashes) {
            // Celui qui n'a pas soumis est en faute
            if (!hashSoumisJ1 && msg.sender == joueur2) {
                vainqueur = joueur2;
            } else if (!hashSoumisJ2 && msg.sender == joueur1) {
                vainqueur = joueur1;
            } else {
                revert TropTot();
            }
        } else {
            // En InProgress : si on attend une réponse, c'est l'adversaire qui doit répondre
            // Si on attend une attaque, c'est le joueur courant qui est inactif
            address joueurInactif = enAttenteReponse
                ? ((joueurCourant == joueur1) ? joueur2 : joueur1)
                : joueurCourant;
            if (msg.sender == joueurInactif) revert TropTot();
            vainqueur = msg.sender;
        }

        uint256 gain = address(this).balance;
        etat = GameState.Finished;

        emit VictoireInactivite(vainqueur, gain);

        (bool succes, ) = vainqueur.call{ value: gain }("");
        require(succes, "Transfert echoue");
    }

    /**
     * @notice Retourne l'état complet de la partie.
     * @return _joueur1 Adresse du joueur 1
     * @return _joueur2 Adresse du joueur 2
     * @return _enjeu Mise en jeu (wei)
     * @return _etat État actuel de la partie
     * @return _joueurCourant Joueur dont c'est le tour
     * @return _enAttenteReponse Vrai si une attaque est en attente de réponse
     * @return _derniereCase Dernière case attaquée
     * @return _nbAttaquesJ1 Nombre d'attaques sur la grille de J1
     * @return _nbAttaquesJ2 Nombre d'attaques sur la grille de J2
     */
    function getGameState()
        external
        view
        returns (
            address _joueur1,
            address _joueur2,
            uint256 _enjeu,
            GameState _etat,
            address _joueurCourant,
            bool _enAttenteReponse,
            uint8 _derniereCase,
            uint256 _nbAttaquesJ1,
            uint256 _nbAttaquesJ2
        )
    {
        return (
            joueur1,
            joueur2,
            enjeu,
            etat,
            joueurCourant,
            enAttenteReponse,
            derniereCase,
            attaquesGrilleJ1.length,
            attaquesGrilleJ2.length
        );
    }

    // ─────────────────────────────────────────────
    //  Fonctions internes
    // ─────────────────────────────────────────────

    /// @dev Vérifie que la case n'a pas déjà été attaquée dans l'historique fourni
    function _verifierCasePasDejaAttaquee(uint8 _case, AttackRecord[] storage _historique) internal view {
        for (uint256 i = 0; i < _historique.length; i++) {
            if (_historique[i].caseVisee == _case) revert CaseDejaAttaquee(_case);
        }
    }

    /// @dev Vérifie que deux cases forment un placement valide (consécutif horizontal ou vertical)
    function _placementConsecutif(uint8 a, uint8 b) internal pure returns (bool) {
        if (a == b) return false;
        // Assurer a < b pour simplifier
        if (a > b) (a, b) = (b, a);
        uint8 diff = b - a;
        // Consécutif horizontal : même rangée, diff == 1, pas de saut de ligne
        if (diff == 1 && (a % 3) != 2) return true;
        // Consécutif vertical : même colonne, diff == 3
        if (diff == 3) return true;
        return false;
    }
}
