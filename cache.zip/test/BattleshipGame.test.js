const { expect } = require("chai");
const { ethers } = require("hardhat");

// ─── Helpers ───────────────────────────────────────────────────────────────

/**
 * Calcule le hash de placement identique au contrat :
 * keccak256(abi.encodePacked(case1, case2, sel))
 */
function computeHash(case1, case2, sel) {
  return ethers.solidityPackedKeccak256(
    ["uint8", "uint8", "bytes32"],
    [case1, case2, sel]
  );
}

const ENJEU = ethers.parseEther("0.01");
const AttackStatus = { Manque: 0, Touche: 1, Coule: 2 };
const GameState = { WaitingPlayer: 0, WaitingHashes: 1, InProgress: 2, Finished: 3 };

// ─── Fixture ───────────────────────────────────────────────────────────────

async function deployFixture() {
  const [owner, j1, j2, other] = await ethers.getSigners();
  const BattleshipGame = await ethers.getContractFactory("BattleshipGame");

  // J1 déploie (joueur1 = j1)
  const game = await BattleshipGame.connect(j1).deploy({ value: ENJEU });
  await game.waitForDeployment();

  return { game, j1, j2, other };
}

async function deployAndJoinFixture() {
  const { game, j1, j2, other } = await deployFixture();
  await game.connect(j2).joinGame({ value: ENJEU });
  return { game, j1, j2, other };
}

async function deployJoinAndHashFixture() {
  const { game, j1, j2, other } = await deployAndJoinFixture();

  const selJ1 = ethers.randomBytes(32);
  const selJ2 = ethers.randomBytes(32);
  // Bateaux valides : J1 → cases 0,1 ; J2 → cases 3,6 (vertical)
  const [c1J1, c2J1] = [0, 1];
  const [c1J2, c2J2] = [3, 6];

  const hashJ1 = computeHash(c1J1, c2J1, selJ1);
  const hashJ2 = computeHash(c1J2, c2J2, selJ2);

  await game.connect(j1).submitHash(hashJ1);
  await game.connect(j2).submitHash(hashJ2);

  return { game, j1, j2, other, selJ1, selJ2, c1J1, c2J1, c1J2, c2J2, hashJ1, hashJ2 };
}

// ═══════════════════════════════════════════════════════════════════════════
//  Tests
// ═══════════════════════════════════════════════════════════════════════════

describe("BattleshipGame", function () {

  // ─── 1. Déploiement & joinGame ──────────────────────────────────────────

  describe("Déploiement et joinGame", function () {
    it("enregistre joueur1 et l'enjeu lors du déploiement", async function () {
      const { game, j1 } = await deployFixture();
      expect(await game.joueur1()).to.equal(j1.address);
      expect(await game.enjeu()).to.equal(ENJEU);
      expect(await game.etat()).to.equal(GameState.WaitingPlayer);
    });

    it("joueur2 rejoint avec le bon enjeu", async function () {
      const { game, j2 } = await deployFixture();
      await expect(game.connect(j2).joinGame({ value: ENJEU }))
        .to.emit(game, "JoueurRejoint")
        .withArgs(j2.address, ENJEU);
      expect(await game.joueur2()).to.equal(j2.address);
      expect(await game.etat()).to.equal(GameState.WaitingHashes);
    });

    it("rejette joinGame si enjeu incorrect", async function () {
      const { game, j2 } = await deployFixture();
      const mauvaisEnjeu = ethers.parseEther("0.005");
      await expect(
        game.connect(j2).joinGame({ value: mauvaisEnjeu })
      ).to.be.revertedWithCustomError(game, "EnjeuIncorrect");
    });

    it("rejette joinGame si la partie est déjà pleine", async function () {
      const { game, j2, other } = await deployFixture();
      await game.connect(j2).joinGame({ value: ENJEU });
      await expect(
        game.connect(other).joinGame({ value: ENJEU })
      ).to.be.revertedWithCustomError(game, "EtatIncorrect");
    });

    it("rejette joinGame si c'est joueur1 lui-même", async function () {
      const { game, j1 } = await deployFixture();
      await expect(
        game.connect(j1).joinGame({ value: ENJEU })
      ).to.be.revertedWithCustomError(game, "PartieDejaPleine");
    });
  });

  // ─── 2. Soumission des hashs ────────────────────────────────────────────

  describe("submitHash", function () {
    it("chaque joueur soumet son hash et la partie démarre", async function () {
      const { game, j1, j2 } = await deployAndJoinFixture();

      const h1 = computeHash(0, 1, ethers.randomBytes(32));
      const h2 = computeHash(3, 6, ethers.randomBytes(32));

      await expect(game.connect(j1).submitHash(h1))
        .to.emit(game, "HashSoumis").withArgs(j1.address);
      expect(await game.etat()).to.equal(GameState.WaitingHashes);

      await expect(game.connect(j2).submitHash(h2))
        .to.emit(game, "HashSoumis").withArgs(j2.address)
        .to.emit(game, "PartieCommencee").withArgs(j2.address); // j2 attaque en premier

      expect(await game.etat()).to.equal(GameState.InProgress);
      expect(await game.joueurCourant()).to.equal(j2.address);
    });

    it("rejette un double soumission de hash", async function () {
      const { game, j1 } = await deployAndJoinFixture();
      const h = computeHash(0, 1, ethers.randomBytes(32));
      await game.connect(j1).submitHash(h);
      await expect(
        game.connect(j1).submitHash(h)
      ).to.be.revertedWithCustomError(game, "HashDejasoumis");
    });

    it("rejette submitHash avant que j2 ait rejoint", async function () {
      const { game, j1 } = await deployFixture();
      const h = computeHash(0, 1, ethers.randomBytes(32));
      await expect(
        game.connect(j1).submitHash(h)
      ).to.be.revertedWithCustomError(game, "EtatIncorrect");
    });
  });

  // ─── 3. Tour complet : attaque + réponse "Manqué" + changement joueur ──

  describe("Tour avec réponse Manqué", function () {
    it("j2 attaque, j1 répond Manqué, c'est au tour de j1", async function () {
      const { game, j1, j2 } = await deployJoinAndHashFixture();

      // j2 attaque la case 5
      await expect(game.connect(j2).attack(5))
        .to.emit(game, "Attaque").withArgs(j2.address, 5);
      expect(await game.enAttenteReponse()).to.be.true;

      // j1 répond Manqué
      await expect(game.connect(j1).respondToAttack(AttackStatus.Manque))
        .to.emit(game, "Reponse").withArgs(j1.address, 5, AttackStatus.Manque);

      // C'est maintenant au tour de j1
      expect(await game.joueurCourant()).to.equal(j1.address);
      expect(await game.enAttenteReponse()).to.be.false;
      expect(await game.etat()).to.equal(GameState.InProgress);
    });

    it("rejette une attaque sur une case hors limites", async function () {
      const { game, j2 } = await deployJoinAndHashFixture();
      await expect(
        game.connect(j2).attack(9)
      ).to.be.revertedWithCustomError(game, "CaseHorsLimites");
    });

    it("rejette une deuxième attaque sur la même case", async function () {
      const { game, j1, j2 } = await deployJoinAndHashFixture();
      await game.connect(j2).attack(5);
      await game.connect(j1).respondToAttack(AttackStatus.Manque);
      // j1 attaque la case 5 (déjà visée par j2 sur la grille de j1 — mais ici j1 attaque la grille de j2)
      await game.connect(j1).attack(7);
      await game.connect(j2).respondToAttack(AttackStatus.Manque);
      // j2 rejoue, il tente de réattaquer la case 5
      await expect(
        game.connect(j2).attack(5)
      ).to.be.revertedWithCustomError(game, "CaseDejaAttaquee");
    });

    it("rejette une attaque si ce n'est pas son tour", async function () {
      const { game, j1 } = await deployJoinAndHashFixture();
      // C'est le tour de j2, pas de j1
      await expect(
        game.connect(j1).attack(0)
      ).to.be.revertedWithCustomError(game, "PasTonTour");
    });
  });

  // ─── 4. Tour avec réponse "Touché" (même joueur rejoue) ─────────────────

  describe("Tour avec réponse Touché", function () {
    it("j2 attaque, j1 répond Touché, j2 rejoue", async function () {
      const { game, j1, j2 } = await deployJoinAndHashFixture();

      await game.connect(j2).attack(2);
      await expect(game.connect(j1).respondToAttack(AttackStatus.Touche))
        .to.emit(game, "Reponse").withArgs(j1.address, 2, AttackStatus.Touche);

      // j2 doit rejouer
      expect(await game.joueurCourant()).to.equal(j2.address);
      expect(await game.enAttenteReponse()).to.be.false;
      expect(await game.etat()).to.equal(GameState.InProgress);
    });
  });

  // ─── 5. Claim de victoire valide ─────────────────────────────────────────

  describe("claimWin", function () {
    it("le vainqueur reçoit les fonds après vérification du hash", async function () {
      const { game, j1, j2, selJ1, selJ2, c1J2, c2J2 } = await deployJoinAndHashFixture();

      // j2 attaque, j1 répond Coulé (donc j2 a gagné)
      await game.connect(j2).attack(0);
      await game.connect(j1).respondToAttack(AttackStatus.Coule);

      expect(await game.etat()).to.equal(GameState.Finished);
      expect(await game.joueurCourant()).to.equal(j2.address);

      const balanceAvant = await ethers.provider.getBalance(j2.address);
      const tx = await game.connect(j2).claimWin(c1J2, c2J2, selJ2);
      const receipt = await tx.wait();
      const gasCost = receipt.gasUsed * tx.gasPrice;
      const balanceApres = await ethers.provider.getBalance(j2.address);

      // j2 doit avoir reçu 2 × ENJEU (moins le gas)
      expect(balanceApres).to.be.closeTo(
        balanceAvant + ENJEU * 2n - gasCost,
        ethers.parseEther("0.001") // tolérance
      );
    });

    it("rejette claimWin avec de mauvaises positions (hash invalide)", async function () {
      const { game, j1, j2, selJ2 } = await deployJoinAndHashFixture();

      await game.connect(j2).attack(0);
      await game.connect(j1).respondToAttack(AttackStatus.Coule);

      // j2 donne de mauvaises cases
      await expect(
        game.connect(j2).claimWin(4, 5, selJ2)
      ).to.be.revertedWithCustomError(game, "HashInvalide");
    });

    it("rejette claimWin avec un mauvais sel", async function () {
      const { game, j1, j2, c1J2, c2J2 } = await deployJoinAndHashFixture();

      await game.connect(j2).attack(0);
      await game.connect(j1).respondToAttack(AttackStatus.Coule);

      const mauvaisSel = ethers.randomBytes(32);
      await expect(
        game.connect(j2).claimWin(c1J2, c2J2, mauvaisSel)
      ).to.be.revertedWithCustomError(game, "HashInvalide");
    });

    it("rejette claimWin avec un placement non consécutif", async function () {
      const { game, j1, j2, selJ2 } = await deployJoinAndHashFixture();

      await game.connect(j2).attack(0);
      await game.connect(j1).respondToAttack(AttackStatus.Coule);

      // Cases 0 et 2 ne sont pas consécutives (saut de ligne)
      await expect(
        game.connect(j2).claimWin(0, 2, selJ2)
      ).to.be.revertedWithCustomError(game, "PlacementInvalide");
    });

    it("rejette claimWin si la partie n'est pas terminée", async function () {
      const { game, j2, selJ2, c1J2, c2J2 } = await deployJoinAndHashFixture();
      await expect(
        game.connect(j2).claimWin(c1J2, c2J2, selJ2)
      ).to.be.revertedWithCustomError(game, "EtatIncorrect");
    });
  });

  // ─── 6. Claim d'inactivité ───────────────────────────────────────────────

  describe("claimInactivity", function () {
    it("rejette claimInactivity si pas assez de blocs écoulés", async function () {
      const { game, j1 } = await deployJoinAndHashFixture();
      // On vient de soumettre les hashs → blocDerniereAction = bloc actuel
      await expect(
        game.connect(j1).claimInactivity()
      ).to.be.revertedWithCustomError(game, "InactiviteInsuffisante");
    });

    it("accepte claimInactivity après BLOCS_INACTIVITE blocs", async function () {
      const { game, j1, j2 } = await deployJoinAndHashFixture();

      // j2 attaque
      await game.connect(j2).attack(8);
      // j1 ne répond pas → on mine 50 blocs
      const blocsRequis = await game.BLOCS_INACTIVITE();
      await ethers.provider.send("hardhat_mine", [`0x${blocsRequis.toString(16)}`]);

      // j1 peut réclamer la victoire par inactivité de j2 (j2 devait répondre)
      // Mais ici c'est j2 qui est en attente de réponse de j1
      // L'appelant doit être celui qui n'est pas en faute.
      // j1 est l'adversaire de j2 (joueurCourant) — c'est j1 qui attend la réponse de... non.
      // Rappel flux : j2 a attaqué → enAttenteReponse = true → c'est J1 qui doit répondre.
      // Inactif = j1. Donc j2 peut réclamer.
      const balanceAvant = await ethers.provider.getBalance(j2.address);
      const tx = await game.connect(j2).claimInactivity();
      const receipt = await tx.wait();
      const gasCost = receipt.gasUsed * tx.gasPrice;
      const balanceApres = await ethers.provider.getBalance(j2.address);

      expect(await game.etat()).to.equal(GameState.Finished);
      expect(balanceApres).to.be.closeTo(
        balanceAvant + ENJEU * 2n - gasCost,
        ethers.parseEther("0.001")
      );
    });

    it("rejette claimInactivity si le demandeur est lui-même le joueur inactif", async function () {
      const { game, j1, j2 } = await deployJoinAndHashFixture();
      await game.connect(j2).attack(8);
      const blocsRequis = await game.BLOCS_INACTIVITE();
      await ethers.provider.send("hardhat_mine", [`0x${blocsRequis.toString(16)}`]);

      // j1 est inactif (doit répondre) — j1 ne peut pas réclamer contre lui-même
      await expect(
        game.connect(j1).claimInactivity()
      ).to.be.revertedWithCustomError(game, "TropTot");
    });
  });

  // ─── 7. getGameState ────────────────────────────────────────────────────

  describe("getGameState", function () {
    it("retourne les informations correctes en début de partie", async function () {
      const { game, j1, j2 } = await deployAndJoinFixture();
      const state = await game.getGameState();
      expect(state._joueur1).to.equal(j1.address);
      expect(state._joueur2).to.equal(j2.address);
      expect(state._enjeu).to.equal(ENJEU);
      expect(state._etat).to.equal(GameState.WaitingHashes);
    });
  });
});
